import java.io.*;
import java.util.*;

public class NoteUtilityApp {
    private static final String STORAGE_FOLDER = "notes";

    public static void main(String[] args) {
        File notesDirectory = new File(STORAGE_FOLDER);
        if (!notesDirectory.exists()) notesDirectory.mkdirs();

        Scanner input = new Scanner(System.in);
        int option;

        while (true) {
            showMenu();
            try {
                option = Integer.parseInt(input.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                continue;
            }

            switch (option) {
                case 1 -> generateNote1(input);
                case 2 -> readAndShowFile("JavaFile1.txt");
                case 3 -> generateNote2();
                case 4 -> copyBetweenFiles("JavaFile1.txt", "JavaFile2.txt");
                case 5 -> examineNote("JavaFile1.txt", input);
                case 6 -> readAndShowFile("JavaFile2.txt");
                case 7 -> {
                    System.out.println("Program terminated.");
                    input.close();
                    return;
                }
                default -> System.out.println("Unrecognized choice.");
            }
        }
    }

    private static void showMenu() {
        System.out.println("\n>>> Notes Manager <<<");
        System.out.println("1. Write to JavaFile1.txt");
        System.out.println("2. View JavaFile1.txt");
        System.out.println("3. Write to JavaFile2.txt");
        System.out.println("4. Copy content JavaFile1.txt ➝ JavaFile2.txt");
        System.out.println("5. Analyze JavaFile1.txt");
        System.out.println("6. View JavaFile2.txt");
        System.out.println("7. Quit");
        System.out.print("Select option: ");
    }

    private static void generateNote1(Scanner scanner) {
        File output = new File(STORAGE_FOLDER, "JavaFile1.txt");
        System.out.println("Start typing content for JavaFile1.txt. Type 'END' on a new line to finish:");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(output))) {
            String inputLine;
            while (!(inputLine = scanner.nextLine()).equalsIgnoreCase("END")) {
                bw.write(inputLine);
                bw.newLine();
            }
            System.out.println("JavaFile1.txt saved successfully.");
        } catch (IOException e) {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }

    private static void generateNote2() {
        String[] content = {
            "This is the first line in this JavaFile2.txt file."
        };
        saveToFile("JavaFile2.txt", content);
        System.out.println("JavaFile2.txt has been created.");
    }

    private static void saveToFile(String fileName, String[] lines) {
        File outFile = new File(STORAGE_FOLDER, fileName);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outFile))) {
            for (String l : lines) {
                writer.write(l);
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Failed to save file: " + e.getMessage());
        }
    }

    private static void readAndShowFile(String fileName) {
        File targetFile = new File(STORAGE_FOLDER, fileName);
        if (!targetFile.exists()) {
            System.out.println("File " + fileName + " does not exist.");
            return;
        }

        System.out.println("\n-- Content of " + fileName + " --");
        try (BufferedReader reader = new BufferedReader(new FileReader(targetFile))) {
            String lineRead;
            while ((lineRead = reader.readLine()) != null) {
                System.out.println(lineRead);
            }
        } catch (IOException e) {
            System.out.println("Unable to open file: " + e.getMessage());
        }
    }

    private static void copyBetweenFiles(String source, String destination) {
        File sourceFile = new File(STORAGE_FOLDER, source);
        File destFile = new File(STORAGE_FOLDER, destination);

        if (!sourceFile.exists()) {
            System.out.println("Source file does not exist.");
            return;
        }

        try (
            BufferedReader reader = new BufferedReader(new FileReader(sourceFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(destFile, true))
        ) {
            String textLine;
            while ((textLine = reader.readLine()) != null) {
                writer.write(textLine);
                writer.newLine();
            }
            System.out.println("Data copied from " + source + " to " + destination);
        } catch (IOException e) {
            System.out.println("Copy failed: " + e.getMessage());
        }

        readAndShowFile(destination);
    }

    private static void examineNote(String filename, Scanner scanner) {
        File file = new File(STORAGE_FOLDER, filename);
        if (!file.exists()) {
            System.out.println("File for analysis not found.");
            return;
        }

        System.out.print("Enter word to search in file: ");
        String targetWord = scanner.nextLine().trim().toLowerCase();

        int lines = 0, words = 0, chars = 0, matchCount = 0;
        int currentLine = 0;

        System.out.println("\nAnalyzing file: " + filename);

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String contentLine;
            while ((contentLine = reader.readLine()) != null) {
                currentLine++;
                lines++;
                chars += contentLine.length();

                String[] terms = contentLine.split("\\s+");
                words += terms.length;

                for (String term : terms) {
                    String cleaned = term.toLowerCase().replaceAll("[^a-z0-9]", "");
                    if (cleaned.equals(targetWord)) {
                        matchCount++;
                        System.out.println("Word '" + targetWord + "' found at line " + currentLine);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Failed to analyze: " + e.getMessage());
            return;
        }

        System.out.println("\nStatistics:");
        System.out.println("Characters: " + chars);
        System.out.println("Words: " + words);
        System.out.println("Lines: " + lines);
        System.out.println("Matches of '" + targetWord + "': " + matchCount);
    }
}
